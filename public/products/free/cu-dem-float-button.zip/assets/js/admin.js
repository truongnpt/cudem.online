( function ( $ ) {
	'use strict';

	$( function () {
		var mediaFrame;
		var strings = window.cudemFloatButtonAdmin || {};
		var activeClasses = 'bg-white text-blue-600 shadow-sm';
		var inactiveClasses = 'text-slate-500';
		var storageKey = 'cudemFloatButtonActiveTab';

		function activateTab( tabName, shouldStore ) {
			var $tab = $( '[data-cfb-tab="' + tabName + '"]' );
			var $panel = $( '[data-cfb-tab-panel="' + tabName + '"]' );

			if ( ! $tab.length || ! $panel.length ) {
				return;
			}

			$( '[data-cfb-tab]' )
				.removeClass( 'nav-tab-active' )
				.removeClass( activeClasses )
				.addClass( inactiveClasses )
				.attr( 'aria-selected', 'false' );
			$tab
				.addClass( 'nav-tab-active' )
				.addClass( activeClasses )
				.removeClass( inactiveClasses )
				.attr( 'aria-selected', 'true' );

			$( '[data-cfb-tab-panel]' )
				.removeClass( 'is-active' )
				.attr( 'hidden', true );
			$panel
				.addClass( 'is-active' )
				.removeAttr( 'hidden' );

			if ( shouldStore ) {
				window.localStorage.setItem( storageKey, tabName );
				window.history.replaceState( null, '', '#tab-' + tabName );
			}
		}

		$( '.cfb-color-picker' ).wpColorPicker();

		activateTab(
			window.location.hash.replace( '#tab-', '' ) ||
				window.localStorage.getItem( storageKey ) ||
				'general',
			false
		);

		$( document ).on( 'click', '[data-cfb-tab]', function ( event ) {
			var $tab = $( event.currentTarget );
			var tabName = $tab.data( 'cfb-tab' );

			event.preventDefault();
			activateTab( tabName, true );
		} );

		$( document ).on( 'click', '.cudem-float-button-upload', function ( event ) {
			var $button = $( event.currentTarget );
			var $field = $button.closest( '.cudem-float-button-icon-field' );
			var $input = $field.find( '.cudem-float-button-icon-input' );
			var $preview = $field.siblings( '.cudem-float-button-preview' );

			event.preventDefault();

			mediaFrame = wp.media( {
				title: strings.mediaTitle || 'Choose logo/icon',
				button: {
					text: strings.mediaButton || 'Use this icon',
				},
				multiple: false,
			} );

			mediaFrame.on( 'select', function () {
				var attachment = mediaFrame.state().get( 'selection' ).first().toJSON();

				$input.val( attachment.url ).trigger( 'change' );
				$preview.empty().append(
					$( '<img>', {
						src: attachment.url,
						alt: '',
					} )
				);
			} );

			mediaFrame.open();
		} );

		$( document ).on( 'click', '.cudem-float-button-clear', function ( event ) {
			var $button = $( event.currentTarget );
			var $field = $button.closest( '.cudem-float-button-icon-field' );

			event.preventDefault();

			$field.find( '.cudem-float-button-icon-input' ).val( '' ).trigger( 'change' );
			$field.siblings( '.cudem-float-button-preview' ).empty();
		} );
	} );
}( jQuery ) );
