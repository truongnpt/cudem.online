<?php
/**
 * Plugin Name: Cudem Float Button
 * Description: Display modern floating contact buttons with customizable positions and basic animations.
 * Version: 1.0.0
 * Author: Cudem.Online
 * Text Domain: cudem-float-button
 * Domain Path: /languages
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Cudem_Float_Button {
	private const OPTION_NAME = 'cudem_float_button_settings';
	private const NONCE_ACTION = 'cudem_float_button_save_settings';
	private const NONCE_NAME = 'cudem_float_button_nonce';

	private static $instance = null;

	public static function instance(): self {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	private function __construct() {
		add_action( 'plugins_loaded', array( $this, 'load_textdomain' ) );
		add_action( 'admin_menu', array( $this, 'register_admin_menu' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_assets' ) );
		add_action( 'admin_post_cudem_float_button_save', array( $this, 'save_settings' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_frontend_assets' ) );
		add_action( 'wp_footer', array( $this, 'render_buttons' ) );
	}

	public function load_textdomain(): void {
		load_plugin_textdomain(
			'cudem-float-button',
			false,
			dirname( plugin_basename( __FILE__ ) ) . '/languages'
		);
	}

	public static function activate(): void {
		if ( false === get_option( self::OPTION_NAME ) ) {
			add_option( self::OPTION_NAME, self::get_default_settings() );
		}
	}

	public function register_admin_menu(): void {
		add_options_page(
			__( 'Cudem Float Button', 'cudem-float-button' ),
			__( 'Cudem Float Button', 'cudem-float-button' ),
			'manage_options',
			'cudem-float-button',
			array( $this, 'render_settings_page' )
		);
	}

	public function enqueue_admin_assets( string $hook_suffix ): void {
		if ( 'settings_page_cudem-float-button' !== $hook_suffix ) {
			return;
		}

		wp_enqueue_media();
		wp_enqueue_script(
			'cudem-float-button-admin',
			plugin_dir_url( __FILE__ ) . 'assets/js/admin.js',
			array( 'jquery', 'wp-color-picker' ),
			'1.0.0',
			true
		);
		wp_enqueue_style( 'wp-color-picker' );
		wp_localize_script(
			'cudem-float-button-admin',
			'cudemFloatButtonAdmin',
			array(
				'mediaTitle' => __( 'Choose logo/icon', 'cudem-float-button' ),
				'mediaButton' => __( 'Use this icon', 'cudem-float-button' ),
			)
		);
		wp_enqueue_style(
			'cudem-float-button-admin',
			plugin_dir_url( __FILE__ ) . 'assets/css/admin.css',
			array(),
			'1.0.0'
		);
	}

	public function enqueue_frontend_assets(): void {
		$settings = $this->get_settings();

		if ( empty( $settings['enabled'] ) || empty( $this->get_visible_buttons( $settings ) ) ) {
			return;
		}

		wp_enqueue_style(
			'cudem-float-button',
			plugin_dir_url( __FILE__ ) . 'assets/css/frontend.css',
			array(),
			'1.0.0'
		);
	}

	public function render_settings_page(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$settings   = $this->get_settings();
		$services   = $this->get_services();
		$positions  = $this->get_positions();
		$animations = $this->get_animations();

		$admin_wrap_class       = 'my-5 mr-5 cudem-float-button-admin rounded-lg bg-gradient-to-br from-white via-slate-50 to-blue-50/70 p-6 text-slate-700  ring-1 ring-slate-200/70';
		$form_class             = 'mt-6 ';
		$tab_button_class       = 'nav-tab rounded-t-lg border-0 px-5 py-3 text-sm font-semibold transition duration-200 hover:bg-white hover:text-blue-600 focus:outline-none focus:ring-4 focus:ring-blue-100';
		$tab_panel_class        = 'cudem-float-button-tab-panel rounded-b-lg border border-[#c3c4c7] bg-white/95 p-6 ';
		$button_card_class      = 'postbox cudem-float-button-box overflow-hidden !rounded-lg border border-slate-200/80 bg-white/95  ring-1 ring-white/80';
		$postbox_header_class   = 'postbox-header border-b border-slate-100 bg-gradient-to-r from-slate-50 to-blue-50/70';
		$field_class            = 'grid gap-3 p-4 md:grid-cols-[180px_1fr] md:items-center';
		$field_label_class      = 'text-sm font-semibold text-slate-700';
		$input_class            = 'regular-text w-full max-w-xl !rounded-lg border border-slate-200 bg-white px-4 py-2.5 text-slate-700  transition focus:border-blue-400 focus:outline-none focus:ring-4 focus:ring-blue-100';
		$select_class           = 'min-w-64 !rounded-lg border border-slate-200 bg-white px-4 py-2.5 text-slate-700  transition focus:border-blue-400 focus:outline-none focus:ring-4 focus:ring-blue-100';
		$checkbox_label_class   = 'inline-flex items-center gap-3 py-2 text-sm font-medium text-slate-700';
		$radio_label_class      = 'mb-2 inline-flex min-w-32 items-center gap-2 rounded-lg bg-slate-50 px-4 py-2 text-sm font-semibold text-slate-700 ring-1 ring-slate-200 transition hover:bg-blue-50';
		$secondary_button_class = 'button !rounded-lg border-slate-200 bg-white px-4 text-slate-700  transition hover:border-blue-300 hover:text-blue-600';
		?>
		<div class="<?php echo esc_attr( $admin_wrap_class ); ?>">
			<h1 class="mb-2 text-3xl font-bold tracking-tight text-slate-900"><?php esc_html_e( 'Cudem Float Button', 'cudem-float-button' ); ?></h1>

			<?php if ( isset( $_GET['settings-updated'] ) && 'true' === $_GET['settings-updated'] ) : ?>
				<div class="notice-success is-dismissible rounded-md !border-1 !border-l-4 !border-green-500 bg-green-50 text-green-800">
					<p><?php esc_html_e( 'Cudem Float Button settings saved.', 'cudem-float-button' ); ?></p>
				</div>
			<?php endif; ?>

			<form class="<?php echo esc_attr( $form_class ); ?>" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="cudem_float_button_save">
				<?php wp_nonce_field( self::NONCE_ACTION, self::NONCE_NAME ); ?>

				<nav class="nav-tab-wrapper cudem-float-button-tabs flex gap-2 !border-b-0" aria-label="<?php esc_attr_e( 'Cudem Float Button settings tabs', 'cudem-float-button' ); ?>">
					<button type="button" class="<?php echo esc_attr( $tab_button_class . ' nav-tab-active text-slate-500' ); ?>" data-cfb-tab="general" aria-controls="cudem-float-button-tab-general" aria-selected="true">
						<?php esc_html_e( 'General', 'cudem-float-button' ); ?>
					</button>
					<button type="button" class="<?php echo esc_attr( $tab_button_class . ' text-slate-500' ); ?>" data-cfb-tab="styles" aria-controls="cudem-float-button-tab-styles" aria-selected="false">
						<?php esc_html_e( 'Styles', 'cudem-float-button' ); ?>
					</button>
					<button type="button" class="<?php echo esc_attr( $tab_button_class . ' text-slate-500' ); ?>" data-cfb-tab="settings" aria-controls="cudem-float-button-tab-settings" aria-selected="false">
						<?php esc_html_e( 'Settings', 'cudem-float-button' ); ?>
					</button>
				</nav>

				<?php
				require __DIR__ . '/includes/admin-tabs/general.php';
				require __DIR__ . '/includes/admin-tabs/styles.php';
				require __DIR__ . '/includes/admin-tabs/settings.php';
				?>

				<?php submit_button( __( 'Save settings', 'cudem-float-button' ), 'primary cfb-primary-submit !rounded-lg px-6' ); ?>
			</form>
		</div>
		<?php
	}

	public function save_settings(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You are not allowed to perform this action.', 'cudem-float-button' ) );
		}

		check_admin_referer( self::NONCE_ACTION, self::NONCE_NAME );

		$raw_settings = isset( $_POST['cudem_float_button'] ) && is_array( $_POST['cudem_float_button'] )
			? wp_unslash( $_POST['cudem_float_button'] )
			: array();

		update_option( self::OPTION_NAME, $this->sanitize_settings( $raw_settings ) );

		wp_safe_redirect(
			add_query_arg(
				array(
					'page'             => 'cudem-float-button',
					'settings-updated' => 'true',
				),
				admin_url( 'options-general.php' )
			)
		);
		exit;
	}

	public function render_buttons(): void {
		$settings = $this->get_settings();
		$buttons  = $this->get_visible_buttons( $settings );

		if ( empty( $settings['enabled'] ) || empty( $buttons ) ) {
			return;
		}

		$position_class  = 'cfb-position-' . $settings['position'];
		$animation_class = 'cfb-animation-' . $settings['animation'];
		$item_class      = 'cfb-item group inline-flex min-h-14 min-w-14 items-center gap-2.5 rounded-full px-4 py-2.5 pl-2.5 text-sm font-bold text-white no-underline shadow-2xl shadow-slate-900/20 ring-1 ring-white/25 backdrop-blur-md transition-all duration-300 ease-out hover:-translate-y-1 hover:scale-[1.03] hover:text-white hover:no-underline focus:text-white focus:no-underline focus:outline-none focus:ring-4 focus:ring-white/40';
		$icon_class      = 'cfb-icon inline-flex size-10 shrink-0 items-center justify-center overflow-hidden rounded-full bg-white/20 text-xs font-extrabold tracking-wide text-white shadow-inner ring-1 ring-white/30';
		$label_class     = 'cfb-label whitespace-nowrap pr-1 font-semibold tracking-wide drop-shadow-sm';
		$container_style = sprintf(
			'z-index:%d;--cfb-top:%s;--cfb-right:%s;--cfb-bottom:%s;--cfb-left:%s;',
			absint( $settings['z_index'] ),
			$settings['top'],
			$settings['right'],
			$settings['bottom'],
			$settings['left']
		);
		?>
		<div class="<?php echo esc_attr( 'cudem-float-button fixed z-[9999] flex gap-3 ' . $position_class ); ?>" style="<?php echo esc_attr( $container_style ); ?>" aria-label="<?php esc_attr_e( 'Contact buttons', 'cudem-float-button' ); ?>">
			<?php foreach ( $buttons as $button ) : ?>
				<?php
				$button_style = ! empty( $button['background_color'] )
					? 'background:' . $button['background_color'] . ';--cfb-animation-color:' . $button['background_color'] . ';'
					: '';
				$button_state_class = empty( $button['show_label'] ) ? ' cfb-item-icon-only' : '';
				?>
				<a
					class="<?php echo esc_attr( $item_class . $button_state_class . ' cfb-service-' . $button['type'] . ' ' . $animation_class ); ?>"
					style="<?php echo esc_attr( $button_style ); ?>"
					href="<?php echo esc_url( $this->get_button_href( $button ) ); ?>"
					target="<?php echo 'phone' === $button['type'] ? '_self' : '_blank'; ?>"
					rel="noopener noreferrer"
					aria-label="<?php echo esc_attr( $button['name'] ); ?>"
				>
					<span class="<?php echo esc_attr( $icon_class ); ?>" aria-hidden="true">
						<?php if ( ! empty( $button['icon'] ) ) : ?>
							<img class="block size-full object-cover" src="<?php echo esc_url( $button['icon'] ); ?>" alt="">
						<?php else : ?>
							<?php echo esc_html( $this->get_fallback_icon_text( $button['name'] ) ); ?>
						<?php endif; ?>
					</span>
					<?php if ( ! empty( $button['show_label'] ) ) : ?>
						<span class="<?php echo esc_attr( $label_class ); ?>"><?php echo esc_html( $button['name'] ); ?></span>
					<?php endif; ?>
				</a>
			<?php endforeach; ?>
		</div>
		<?php
	}

	private function get_settings(): array {
		$settings = get_option( self::OPTION_NAME, array() );

		if ( ! is_array( $settings ) ) {
			$settings = array();
		}

		$defaults = self::get_default_settings();
		$settings = wp_parse_args( $settings, $defaults );
		$settings['enabled'] = ! empty( $settings['enabled'] );
		$settings['position'] = $this->normalize_position( (string) $settings['position'] );
		$settings['animation'] = in_array( $settings['animation'], array_keys( $this->get_animations() ), true ) ? $settings['animation'] : $defaults['animation'];
		$settings['z_index'] = absint( $settings['z_index'] );
		$settings['top'] = $this->sanitize_css_length( (string) $settings['top'], $defaults['top'] );
		$settings['right'] = $this->sanitize_css_length( (string) $settings['right'], $defaults['right'] );
		$settings['bottom'] = $this->sanitize_css_length( (string) $settings['bottom'], $defaults['bottom'] );
		$settings['left'] = $this->sanitize_css_length( (string) $settings['left'], $defaults['left'] );

		for ( $i = 0; $i < 2; $i++ ) {
			$button = isset( $settings['buttons'][ $i ] ) && is_array( $settings['buttons'][ $i ] )
				? $settings['buttons'][ $i ]
				: array();

			$settings['buttons'][ $i ] = wp_parse_args( $button, $defaults['buttons'][ $i ] );
			$settings['buttons'][ $i ]['show_label'] = ! empty( $settings['buttons'][ $i ]['show_label'] );
			$settings['buttons'][ $i ]['background_color'] = $this->sanitize_hex_color_value(
				(string) $settings['buttons'][ $i ]['background_color'],
				$defaults['buttons'][ $i ]['background_color']
			);
		}

		$settings['buttons'] = array_slice( $settings['buttons'], 0, 2 );

		return $settings;
	}

	private function sanitize_settings( array $settings ): array {
		$positions  = array_keys( $this->get_positions() );
		$animations = array_keys( $this->get_animations() );
		$services   = array_keys( $this->get_services() );
		$defaults   = self::get_default_settings();

		$position  = isset( $settings['position'] ) ? sanitize_key( $settings['position'] ) : $defaults['position'];
		$animation = isset( $settings['animation'] ) ? sanitize_key( $settings['animation'] ) : $defaults['animation'];
		$buttons   = isset( $settings['buttons'] ) && is_array( $settings['buttons'] ) ? $settings['buttons'] : array();

		$sanitized = array(
			'enabled'   => isset( $settings['enabled'] ) ? '1' === (string) $settings['enabled'] : $defaults['enabled'],
			'position'  => in_array( $position, $positions, true ) ? $position : $this->normalize_position( $position ),
			'animation' => in_array( $animation, $animations, true ) ? $animation : $defaults['animation'],
			'z_index'   => isset( $settings['z_index'] ) ? absint( $settings['z_index'] ) : $defaults['z_index'],
			'top'       => isset( $settings['top'] ) ? $this->sanitize_css_length( (string) $settings['top'], $defaults['top'] ) : $defaults['top'],
			'right'     => isset( $settings['right'] ) ? $this->sanitize_css_length( (string) $settings['right'], $defaults['right'] ) : $defaults['right'],
			'bottom'    => isset( $settings['bottom'] ) ? $this->sanitize_css_length( (string) $settings['bottom'], $defaults['bottom'] ) : $defaults['bottom'],
			'left'      => isset( $settings['left'] ) ? $this->sanitize_css_length( (string) $settings['left'], $defaults['left'] ) : $defaults['left'],
			'buttons'   => array(),
		);

		for ( $i = 0; $i < 2; $i++ ) {
			$button = isset( $buttons[ $i ] ) && is_array( $buttons[ $i ] ) ? $buttons[ $i ] : array();
			$type   = isset( $button['type'] ) ? sanitize_key( $button['type'] ) : $defaults['buttons'][ $i ]['type'];

			$sanitized['buttons'][] = array(
				'enabled'          => ! empty( $button['enabled'] ),
				'show_label'       => ! empty( $button['show_label'] ),
				'type'             => in_array( $type, $services, true ) ? $type : $defaults['buttons'][ $i ]['type'],
				'name'             => isset( $button['name'] ) ? sanitize_text_field( $button['name'] ) : '',
				'url'              => isset( $button['url'] ) ? sanitize_text_field( $button['url'] ) : '',
				'icon'             => isset( $button['icon'] ) ? esc_url_raw( $button['icon'] ) : '',
				'background_color' => isset( $button['background_color'] )
					? $this->sanitize_hex_color_value( (string) $button['background_color'], $defaults['buttons'][ $i ]['background_color'] )
					: $defaults['buttons'][ $i ]['background_color'],
			);
		}

		return $sanitized;
	}

	private function get_visible_buttons( array $settings ): array {
		$buttons = isset( $settings['buttons'] ) && is_array( $settings['buttons'] ) ? $settings['buttons'] : array();

		return array_values(
			array_filter(
				array_slice( $buttons, 0, 2 ),
				function ( array $button ): bool {
					return ! empty( $button['enabled'] ) && ! empty( $button['name'] ) && ! empty( $button['url'] );
				}
			)
		);
	}

	private function normalize_position( string $position ): string {
		$legacy_positions = array(
			'left'   => 'bottom-left',
			'right'  => 'bottom-right',
			'top'    => 'top-center',
			'bottom' => 'bottom-center',
		);

		if ( isset( $legacy_positions[ $position ] ) ) {
			return $legacy_positions[ $position ];
		}

		return in_array( $position, array_keys( $this->get_positions() ), true ) ? $position : self::get_default_settings()['position'];
	}

	private function sanitize_css_length( string $value, string $default ): string {
		$value = trim( sanitize_text_field( $value ) );

		if ( preg_match( '/^-?(?:0|(?:\d+|\d*\.\d+)(?:px|rem|em|%|vh|vw))$/', $value ) ) {
			return $value;
		}

		return $default;
	}

	private function sanitize_hex_color_value( string $value, string $default = '' ): string {
		$value = trim( $value );

		if ( '' === $value ) {
			return '';
		}

		$color = sanitize_hex_color( $value );

		return is_string( $color ) ? $color : $default;
	}

	private function get_button_href( array $button ): string {
		if ( 'phone' !== $button['type'] ) {
			return $button['url'];
		}

		if ( 0 === strpos( $button['url'], 'tel:' ) ) {
			return $button['url'];
		}

		$phone = preg_replace( '/[^0-9+]/', '', $button['url'] );

		return 'tel:' . $phone;
	}

	private function get_fallback_icon_text( string $name ): string {
		$name = trim( $name );

		if ( '' === $name ) {
			return 'CFB';
		}

		if ( function_exists( 'mb_substr' ) && function_exists( 'mb_strtoupper' ) ) {
			return mb_strtoupper( mb_substr( $name, 0, 2 ) );
		}

		return strtoupper( substr( $name, 0, 2 ) );
	}

	private function get_services(): array {
		return array(
			'messenger' => __( 'Messenger', 'cudem-float-button' ),
			'zalo'      => __( 'Zalo', 'cudem-float-button' ),
			'telegram'  => __( 'Telegram', 'cudem-float-button' ),
			'whatsapp'  => __( 'WhatsApp', 'cudem-float-button' ),
			'phone'     => __( 'Phone call', 'cudem-float-button' ),
			'custom'    => __( 'Custom link', 'cudem-float-button' ),
		);
	}

	private function get_positions(): array {
		return array(
			'top-left'      => __( 'Top left', 'cudem-float-button' ),
			'top-right'     => __( 'Top right', 'cudem-float-button' ),
			'top-center'    => __( 'Top center', 'cudem-float-button' ),
			'bottom-left'   => __( 'Bottom left', 'cudem-float-button' ),
			'bottom-right'  => __( 'Bottom right', 'cudem-float-button' ),
			'bottom-center' => __( 'Bottom center', 'cudem-float-button' ),
		);
	}

	private function get_animations(): array {
		return array(
			'pulse'  => __( 'Pulse', 'cudem-float-button' ),
			'shake'  => __( 'Shake', 'cudem-float-button' ),
			'bounce' => __( 'Bounce', 'cudem-float-button' ),
		);
	}

	private static function get_default_settings(): array {
		return array(
			'enabled'   => true,
			'position'  => 'bottom-right',
			'animation' => 'pulse',
			'z_index'   => 9999,
			'top'       => '24px',
			'right'     => '24px',
			'bottom'    => '24px',
			'left'      => '24px',
			'buttons'   => array(
				array(
					'enabled' => true,
					'show_label' => true,
					'type'    => 'messenger',
					'name'    => 'Messenger',
					'url'     => '',
					'icon'    => '',
					'background_color' => '',
				),
				array(
					'enabled' => true,
					'show_label' => true,
					'type'    => 'zalo',
					'name'    => 'Zalo',
					'url'     => '',
					'icon'    => '',
					'background_color' => '',
				),
			),
		);
	}
}

register_activation_hook( __FILE__, array( 'Cudem_Float_Button', 'activate' ) );
Cudem_Float_Button::instance();
