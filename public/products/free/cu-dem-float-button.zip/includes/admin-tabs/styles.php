<?php
/**
 * Styles tab template.
 *
 * @package Cudem_Float_Button
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Variables are provided by Cudem_Float_Button::render_settings_page().
 *
 * @var array  $settings
 * @var array  $positions
 * @var array  $animations
 * @var string $tab_panel_class
 * @var string $field_class
 * @var string $field_label_class
 * @var string $select_class
 * @var string $input_class
 */
?>
<div id="cudem-float-button-tab-styles" class="<?php echo esc_attr( $tab_panel_class ); ?>" data-cfb-tab-panel="styles" hidden>
	<h2 class="mt-0 text-2xl font-bold text-slate-900"><?php esc_html_e( 'Styles', 'cudem-float-button' ); ?></h2>

	<div class="space-y-4">
		<div class="<?php echo esc_attr( $field_class ); ?>">
			<label class="<?php echo esc_attr( $field_label_class ); ?>" for="cudem_float_button_position"><?php esc_html_e( 'Display position', 'cudem-float-button' ); ?></label>
			<div>
				<select class="<?php echo esc_attr( $select_class ); ?>" id="cudem_float_button_position" name="cudem_float_button[position]">
					<?php foreach ( $positions as $value => $label ) : ?>
						<option value="<?php echo esc_attr( $value ); ?>" <?php selected( $settings['position'], $value ); ?>>
							<?php echo esc_html( $label ); ?>
						</option>
					<?php endforeach; ?>
				</select>
			</div>
		</div>

		<div class="<?php echo esc_attr( $field_class ); ?>">
			<label class="<?php echo esc_attr( $field_label_class ); ?>" for="cudem_float_button_animation"><?php esc_html_e( 'Animation', 'cudem-float-button' ); ?></label>
			<div>
				<select class="<?php echo esc_attr( $select_class ); ?>" id="cudem_float_button_animation" name="cudem_float_button[animation]">
					<?php foreach ( $animations as $value => $label ) : ?>
						<option value="<?php echo esc_attr( $value ); ?>" <?php selected( $settings['animation'], $value ); ?>>
							<?php echo esc_html( $label ); ?>
						</option>
					<?php endforeach; ?>
				</select>
			</div>
		</div>

		<div class="<?php echo esc_attr( $field_class ); ?>">
			<label class="<?php echo esc_attr( $field_label_class ); ?>" for="cudem_float_button_z_index"><?php esc_html_e( 'Z-index', 'cudem-float-button' ); ?></label>
			<div>
				<input
					type="number"
					class="<?php echo esc_attr( $input_class ); ?>"
					id="cudem_float_button_z_index"
					name="cudem_float_button[z_index]"
					value="<?php echo esc_attr( (string) $settings['z_index'] ); ?>"
					min="0"
					step="1"
				>
			</div>
		</div>

		<div class="<?php echo esc_attr( $field_class ); ?>">
			<label class="<?php echo esc_attr( $field_label_class ); ?>" for="cudem_float_button_top"><?php esc_html_e( 'Top', 'cudem-float-button' ); ?></label>
			<div>
				<input
					type="text"
					class="<?php echo esc_attr( $input_class ); ?>"
					id="cudem_float_button_top"
					name="cudem_float_button[top]"
					value="<?php echo esc_attr( $settings['top'] ); ?>"
					placeholder="24px"
				>
			</div>
		</div>

		<div class="<?php echo esc_attr( $field_class ); ?>">
			<label class="<?php echo esc_attr( $field_label_class ); ?>" for="cudem_float_button_right"><?php esc_html_e( 'Right', 'cudem-float-button' ); ?></label>
			<div>
				<input
					type="text"
					class="<?php echo esc_attr( $input_class ); ?>"
					id="cudem_float_button_right"
					name="cudem_float_button[right]"
					value="<?php echo esc_attr( $settings['right'] ); ?>"
					placeholder="24px"
				>
			</div>
		</div>

		<div class="<?php echo esc_attr( $field_class ); ?>">
			<label class="<?php echo esc_attr( $field_label_class ); ?>" for="cudem_float_button_bottom"><?php esc_html_e( 'Bottom', 'cudem-float-button' ); ?></label>
			<div>
				<input
					type="text"
					class="<?php echo esc_attr( $input_class ); ?>"
					id="cudem_float_button_bottom"
					name="cudem_float_button[bottom]"
					value="<?php echo esc_attr( $settings['bottom'] ); ?>"
					placeholder="24px"
				>
			</div>
		</div>

		<div class="<?php echo esc_attr( $field_class ); ?>">
			<label class="<?php echo esc_attr( $field_label_class ); ?>" for="cudem_float_button_left"><?php esc_html_e( 'Left', 'cudem-float-button' ); ?></label>
			<div>
				<input
					type="text"
					class="<?php echo esc_attr( $input_class ); ?>"
					id="cudem_float_button_left"
					name="cudem_float_button[left]"
					value="<?php echo esc_attr( $settings['left'] ); ?>"
					placeholder="24px"
				>
			</div>
		</div>
	</div>
</div>
