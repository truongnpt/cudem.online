<?php
/**
 * General tab template.
 *
 * @package Cudem_Float_Button
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Variables are provided by Cudem_Float_Button::render_settings_page().
 *
 * @var array  $settings
 * @var array  $services
 * @var string $tab_panel_class
 * @var string $button_card_class
 * @var string $postbox_header_class
 * @var string $field_class
 * @var string $field_label_class
 * @var string $checkbox_label_class
 * @var string $select_class
 * @var string $input_class
 * @var string $secondary_button_class
 */
?>
<div id="cudem-float-button-tab-general" class="<?php echo esc_attr( $tab_panel_class . ' is-active' ); ?>" data-cfb-tab-panel="general">
	<h2 class="mt-0 text-2xl font-bold text-slate-900"><?php esc_html_e( 'Contact buttons', 'cudem-float-button' ); ?></h2>
	<p class="mb-6 text-sm text-slate-500"><?php esc_html_e( 'Manage up to 2 floating contact buttons in the Free version.', 'cudem-float-button' ); ?></p>

	<?php foreach ( $settings['buttons'] as $index => $button ) : ?>
		<div class="<?php echo esc_attr( $button_card_class ); ?>">
			<div class="<?php echo esc_attr( $postbox_header_class ); ?>">
				<?php /* translators: %d: Button number. */ ?>
				<h2 class="text-base font-bold text-slate-800 !my-0"><?php echo esc_html( sprintf( __( 'Button %d', 'cudem-float-button' ), $index + 1 ) ); ?></h2>
			</div>
			<div class="inside space-y-4 p-5">
				<div class="<?php echo esc_attr( $field_class ); ?>">
					<div class="<?php echo esc_attr( $field_label_class ); ?>"><?php esc_html_e( 'Display', 'cudem-float-button' ); ?></div>
					<div>
						<label class="<?php echo esc_attr( $checkbox_label_class ); ?>">
							<input type="checkbox" name="cudem_float_button[buttons][<?php echo esc_attr( (string) $index ); ?>][enabled]" value="1" <?php checked( ! empty( $button['enabled'] ) ); ?>>
							<?php esc_html_e( 'Show this button', 'cudem-float-button' ); ?>
						</label>
					</div>
				</div>

				<div class="<?php echo esc_attr( $field_class ); ?>">
					<div class="<?php echo esc_attr( $field_label_class ); ?>"><?php esc_html_e( 'Label visibility', 'cudem-float-button' ); ?></div>
					<div>
						<label class="<?php echo esc_attr( $checkbox_label_class ); ?>">
							<input type="checkbox" name="cudem_float_button[buttons][<?php echo esc_attr( (string) $index ); ?>][show_label]" value="1" <?php checked( ! empty( $button['show_label'] ) ); ?>>
							<?php esc_html_e( 'Show label', 'cudem-float-button' ); ?>
						</label>
					</div>
				</div>

				<div class="<?php echo esc_attr( $field_class ); ?>">
					<label class="<?php echo esc_attr( $field_label_class ); ?>" for="cudem_float_button_type_<?php echo esc_attr( (string) $index ); ?>"><?php esc_html_e( 'Button type', 'cudem-float-button' ); ?></label>
					<div>
						<select class="<?php echo esc_attr( $select_class ); ?>" id="cudem_float_button_type_<?php echo esc_attr( (string) $index ); ?>" name="cudem_float_button[buttons][<?php echo esc_attr( (string) $index ); ?>][type]">
							<?php foreach ( $services as $value => $label ) : ?>
								<option value="<?php echo esc_attr( $value ); ?>" <?php selected( $button['type'], $value ); ?>>
									<?php echo esc_html( $label ); ?>
								</option>
							<?php endforeach; ?>
						</select>
					</div>
				</div>

				<div class="<?php echo esc_attr( $field_class ); ?>">
					<label class="<?php echo esc_attr( $field_label_class ); ?>" for="cudem_float_button_background_color_<?php echo esc_attr( (string) $index ); ?>"><?php esc_html_e( 'Background color', 'cudem-float-button' ); ?></label>
					<div class="[&_.wp-color-result-text]:h-[40px] [&_.wp-color-result-text]:!leading-[40px] [&_.button]:!rounded-lg [&_.button]:!border-slate-400 [&_.button]:!overflow-hidden">
						<input
							type="text"
							class="cfb-color-picker"
							id="cudem_float_button_background_color_<?php echo esc_attr( (string) $index ); ?>"
							name="cudem_float_button[buttons][<?php echo esc_attr( (string) $index ); ?>][background_color]"
							value="<?php echo esc_attr( $button['background_color'] ); ?>"
							data-default-color=""
						>
					</div>
				</div>

				<div class="<?php echo esc_attr( $field_class ); ?>">
					<label class="<?php echo esc_attr( $field_label_class ); ?>" for="cudem_float_button_name_<?php echo esc_attr( (string) $index ); ?>"><?php esc_html_e( 'Button name', 'cudem-float-button' ); ?></label>
					<div>
						<input
							type="text"
							class="<?php echo esc_attr( $input_class ); ?>"
							id="cudem_float_button_name_<?php echo esc_attr( (string) $index ); ?>"
							name="cudem_float_button[buttons][<?php echo esc_attr( (string) $index ); ?>][name]"
							value="<?php echo esc_attr( $button['name'] ); ?>"
						>
					</div>
				</div>

				<div class="<?php echo esc_attr( $field_class ); ?>">
					<label class="<?php echo esc_attr( $field_label_class ); ?>" for="cudem_float_button_url_<?php echo esc_attr( (string) $index ); ?>"><?php esc_html_e( 'Link URL / Phone number', 'cudem-float-button' ); ?></label>
					<div>
						<input
							type="text"
							class="<?php echo esc_attr( $input_class ); ?>"
							id="cudem_float_button_url_<?php echo esc_attr( (string) $index ); ?>"
							name="cudem_float_button[buttons][<?php echo esc_attr( (string) $index ); ?>][url]"
							value="<?php echo esc_attr( $button['url'] ); ?>"
							placeholder="https://example.com or 0901234567"
						>
					</div>
				</div>

				<div class="<?php echo esc_attr( $field_class ); ?>">
					<label class="<?php echo esc_attr( $field_label_class ); ?>" for="cudem_float_button_icon_<?php echo esc_attr( (string) $index ); ?>"><?php esc_html_e( 'Logo / Icon', 'cudem-float-button' ); ?></label>
					<div>
						<div class="cudem-float-button-icon-field">
							<input
								type="url"
								class="<?php echo esc_attr( $input_class . ' cudem-float-button-icon-input' ); ?>"
								id="cudem_float_button_icon_<?php echo esc_attr( (string) $index ); ?>"
								name="cudem_float_button[buttons][<?php echo esc_attr( (string) $index ); ?>][icon]"
								value="<?php echo esc_url( $button['icon'] ); ?>"
							>
							<button type="button" class="<?php echo esc_attr( $secondary_button_class . ' cudem-float-button-upload' ); ?>"><?php esc_html_e( 'Upload icon', 'cudem-float-button' ); ?></button>
							<button type="button" class="<?php echo esc_attr( $secondary_button_class . ' cudem-float-button-clear' ); ?>"><?php esc_html_e( 'Clear', 'cudem-float-button' ); ?></button>
						</div>
						<div class="cudem-float-button-preview" aria-live="polite">
							<?php if ( ! empty( $button['icon'] ) ) : ?>
								<img src="<?php echo esc_url( $button['icon'] ); ?>" alt="">
							<?php endif; ?>
						</div>
					</div>
				</div>
			</div>
		</div>
	<?php endforeach; ?>
</div>
