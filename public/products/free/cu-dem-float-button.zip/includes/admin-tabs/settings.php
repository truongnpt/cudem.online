<?php
/**
 * Settings tab template.
 *
 * @package Cudem_Float_Button
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Variables are provided by Cudem_Float_Button::render_settings_page().
 *
 * @var array  $settings
 * @var string $tab_panel_class
 * @var string $field_class
 * @var string $field_label_class
 * @var string $radio_label_class
 */
?>
<div id="cudem-float-button-tab-settings" class="<?php echo esc_attr( $tab_panel_class ); ?>" data-cfb-tab-panel="settings" hidden>
	<h2 class="mt-0 text-2xl font-bold text-slate-900"><?php esc_html_e( 'Settings', 'cudem-float-button' ); ?></h2>

	<div class="<?php echo esc_attr( $field_class ); ?>">
		<div class="<?php echo esc_attr( $field_label_class ); ?>"><?php esc_html_e( 'Float button visibility', 'cudem-float-button' ); ?></div>
		<div class="flex flex-col gap-2">
		<fieldset class="flex items-center gap-2">
			<label class="<?php echo esc_attr( $radio_label_class ); ?>">
				<input type="radio" name="cudem_float_button[enabled]" value="1" <?php checked( ! empty( $settings['enabled'] ) ); ?>>
				<?php esc_html_e( 'Enable', 'cudem-float-button' ); ?>
			</label>
			<label class="<?php echo esc_attr( $radio_label_class ); ?>">
				<input type="radio" name="cudem_float_button[enabled]" value="0" <?php checked( empty( $settings['enabled'] ) ); ?>>
				<?php esc_html_e( 'Disable', 'cudem-float-button' ); ?>
			</label>
		</fieldset>
		<p class="description mt-2 text-slate-500"><?php esc_html_e( 'Turn all floating buttons on or off on the frontend.', 'cudem-float-button' ); ?></p>
		</div>
	</div>
	
</div>
